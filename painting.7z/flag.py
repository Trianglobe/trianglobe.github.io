import turtle as t
import basic_shape as bs
from math import *


def main():
    chinese_flag()


def chinese_flag():
    # 设置画布参数。
    width = 1800
    height = 1200
    t.title("Chinese Flag")
    t.setup(width, height)
    t.speed(10)
    # 绘制背景。
    bs.move_to(-width / 2, height / 2)
    bs.rectangle(width, height, "red")
    # 绘制大星。
    main_pos_x = -width / 3
    main_pos_y = height / 4
    bs.move_to(main_pos_x, main_pos_y)
    bs.star(height * 3 / 20, "yellow")
    # 绘制小星。
    stars_pos_x = [-width / 6, -width / 10, -width / 10, -width / 6]
    stars_pos_y = [height * 2 / 5, height * 3 / 10, height * 3 / 20, height / 20]
    for i in range(4):
        bs.move_to(stars_pos_x[i], stars_pos_y[i])
        rotation = atan(abs(stars_pos_y[i] - main_pos_y) / abs(stars_pos_x[i] - main_pos_x))
        if i < 2:
            rotation = radians(18) + rotation
        else:
            rotation = radians(378) - rotation
        t.setheading(degrees(rotation))
        bs.star(height / 20, "yellow")
    # 绘制边框。
    bs.border(width, height)
    t.done()


def american_flag():
    # 设置画布参数。
    width = 950
    height = 500
    t.title("American Flag")
    t.setup(width, height)
    t.speed(30)
    # 绘制条纹。
    for i in range(13):
        bs.move_to(-width / 2, height / 2 - i * height / 13)
        if i % 2 == 0:
            bs.rectangle(width, height / 13, "firebrick")
        else:
            bs.rectangle(width, height / 13, "white")
    # 绘制蓝底。
    bs.move_to(-width / 2, height / 2)
    bs.rectangle(width * 2 / 5, height * 7 / 13 - 1, "navy")
    # 绘制星星。
    space_x = width / 30
    space_y = height * 7 / 130
    for i in range(9):
        for j in range(6 - i % 2):
            bs.move_to(-width / 2 + (2 * j + 1 + i % 2) * space_x, height / 2 - (i + 1) * space_y)
            bs.star(height * 77 / 2500, "white")
    # 绘制边框。
    bs.border(width, height)
    t.done()


def japanese_flag():
    # 设置画布参数。
    width = 900
    height = 600
    t.title("Japanese Flag")
    t.setup(width, height)
    t.speed(10)
    # 绘制背景。
    bs.move_to(-width / 2, height / 2)
    bs.rectangle(width, height, "white")
    # 绘制圆。
    bs.move_to(0, 0)
    bs.circle(height * 3 / 10, "red")
    # 绘制边框。
    bs.border(width, height)
    t.done()


def french_flag():
    # 设置画布参数。
    width = 900
    height = 600
    t.title("French Flag")
    t.setup(width, height)
    t.speed(10)
    # 绘制色块。
    tri_color = ["mediumblue", "white", "red"]
    tri_begin = 0
    for i in range(3):
        bs.move_to(-width / 2 + tri_begin, height / 2)
        bs.rectangle(width / 3, height, tri_color[i])
        tri_begin += width / 3
    # 绘制边框。
    bs.border(width, height)
    t.done()


def british_flag():
    # 设置画布参数。
    width = 1000
    height = 500
    t.title("British Flag")
    t.setup(width, height)
    t.speed(10)
    # 绘制背景。
    bs.move_to(-width / 2, height / 2)
    bs.rectangle(width, height, "darkblue")
    # 绘制白十字。
    bs.move_to(-width * 103 / 1240, height / 2)
    bs.rectangle(width * 103 / 620, height, "white")
    bs.move_to(-width / 2, height * 103 / 620)
    bs.rectangle(width, height * 103 / 310, "white")
    # 绘制白斜十。
    cross_pos_x = [-width / 2, width / 2, -width / 2, width / 2]
    cross_pos_y = [height / 2, -height / 2, -height / 2, height / 2]
    rotations = [0, 180, 0, 180]
    sides = [width * 7 / 62, width * 123 / 124, height * 69 / 620, height * sqrt(5)]
    angles = [degrees(atan(0.5)), degrees(atan(2)), 180 - degrees(atan(2))]
    angles_m = [360 - degrees(atan(0.5)), 360 - degrees(atan(2)), 180 + degrees(atan(2))]
    for i in range(4):
        bs.move_to(cross_pos_x[i], cross_pos_y[i])
        t.setheading(rotations[i])
        if i < 2:
            bs.polygon(sides, angles, "white")
        else:
            bs.polygon(sides, angles_m, "white")
    # 绘制红十字。
    bs.move_to(-width / 20, height / 2)
    bs.rectangle(width / 10, height, "red")
    bs.move_to(-width / 2, height / 10)
    bs.rectangle(width, height / 5, "red")
    # 绘制红斜十。
    cross_pos_x = [-width / 2, width / 2, -width / 2, width / 2]
    cross_pos_y = [height / 2, -height / 2, -height / 2, height / 2]
    rotations = [270, 90, 0, 180]
    sides_a = [width * 23 / 620, height * 161 / 620 * sqrt(5), width * 23 / 310, height * 207 / 620 * sqrt(5)]
    sides_b = [width * 23 / 310, height * 207 / 620 * sqrt(5), width * 23 / 310, height * 207 / 620 * sqrt(5)]
    angles_a = [360 - degrees(atan(2)), 360 - degrees(atan(0.5)), 180 + degrees(atan(0.5))]
    angles_b = [360 - degrees(atan(0.5)), 180 + degrees(atan(0.5)), 360 - degrees(atan(0.5))]
    for i in range(4):
        bs.move_to(cross_pos_x[i], cross_pos_y[i])
        t.setheading(rotations[i])
        if i < 2:
            bs.polygon(sides_a, angles_a, "red")
        else:
            bs.polygon(sides_b, angles_b, "red")
    # 绘制边框。
    bs.border(width, height)
    t.done()


def greek_flag():
    # 设置画布参数。
    width = 900
    height = 600
    t.title("Greek Flag")
    t.setup(width, height)
    t.speed(15)
    # 绘制条纹。
    for i in range(9):
        bs.move_to(-width / 2, height / 2 - i * height / 9)
        if i % 2 == 0:
            bs.rectangle(width, height / 9, "royalblue")
        else:
            bs.rectangle(width, height / 9, "white")
    # 绘制蓝底。
    bs.move_to(-width / 2, height / 2)
    bs.rectangle(height * 5 / 9, height * 5 / 9 - 1, "royalblue")
    # 绘制白十字。
    bs.move_to(-width / 2, height / 2 - height * 2 / 9)
    bs.rectangle(height * 5 / 9, height / 9, "white")
    bs.move_to(-width / 2 + height * 2 / 9, height / 2)
    bs.rectangle(height / 9, height * 5 / 9, "white")
    # 绘制边框。
    bs.border(width, height)
    t.done()


def israel_flag():
    # 设置画布参数。
    width = 825
    height = 600
    t.title("Israel Flag")
    t.setup(width, height)
    t.speed(10)
    # 绘制背景。
    bs.move_to(-width / 2, height / 2)
    bs.rectangle(width, height, "white")
    # 绘制蓝条。
    for i in range(2):
        bs.move_to(-width / 2, height * 13 / 32 - i * height * 21 / 32)
        bs.rectangle(width, height * 5 / 32, "navy")
    # 绘制边框。
    bs.border(width, height)
    t.done()


def n_korean_flag():
    # 设置画布参数。
    width = 900
    height = 600
    t.title("S.Korean Flag")
    t.setup(width, height)
    t.speed(10)
    # 绘制背景。
    bs.move_to(-width / 2, height / 2)
    bs.rectangle(width, height, "white")
    # 绘制边框。
    bs.border(width, height)
    t.done()


def s_korean_flag():
    # 设置画布参数。
    width = 900
    height = 600
    t.title("S.Korean Flag")
    t.setup(width, height)
    t.speed(10)
    # 绘制背景。
    bs.move_to(-width / 2, height / 2)
    bs.rectangle(width, height, "white")
    # 绘制圆。
    colors = ["red", "darkblue"]
    for i in range(2):
        bs.move_to(0, 0)
        t.color(colors[i], colors[i])
        t.begin_fill()
        t.setheading(180 * ((i + 1) % 2) + degrees(atan(3 / 2)))
        t.circle(- height / 8, 180)
        bs.move_to(0, 0)
        t.setheading(180 * i + degrees(atan(3 / 2)))
        t.circle(- height / 8, 180)
        t.setheading(180 * i + degrees(atan(3 / 2)))
        t.circle(height / 4, 180)
        t.end_fill()
    # 绘制边角。
    pos_x = height * 5 / 12 * cos(atan(2 / 3)) - height / 8 * cos(atan(3 / 2))
    pos_y = height * 5 / 12 * sin(atan(2 / 3)) + height / 8 * sin(atan(3 / 2))
    space_x = height * 3 / 48 * cos(atan(2 / 3))
    space_y = height * 3 / 48 * sin(atan(2 / 3))
    sign_x = [1, -1, -1, 1]
    sign_y = [1, -1, 1, -1]
    rotation = [360 - degrees(atan(3 / 2)), 180 - degrees(atan(3 / 2)),
                360 - degrees(atan(2 / 3)), 180 - degrees(atan(2 / 3))]
    for i in range(4):
        for j in range(3):
            bs.move_to(sign_x[i] * (pos_x + j * space_x), sign_y[i] * (pos_y + j * space_y))
            t.setheading(rotation[i])
            if i < 2:
                bs.rectangle(height / 4, height / 24, "black")
            else:
                bs.rectangle(height / 24, height / 4, "black")
    pos_x = (height * 5 / 12) * cos(atan(2 / 3))
    pos_y = (height * 5 / 12) * sin(atan(2 / 3)) + height / 96 / sin(atan(3 / 2))
    for i in range(4):
        for j in range(3):
            if ((i == 0) & (j != 1)) | (i & j == 1) | (i == 3):
                bs.move_to(sign_x[i] * (pos_x + j * space_x), sign_y[i] * (pos_y + j * space_y))
                t.setheading(rotation[i])
                if i < 2:
                    bs.rectangle(height / 48, height / 24 + height / 96 / cos(atan(3 / 2)), "white")
                else:
                    bs.rectangle(height / 24 + height / 96 / cos(atan(3 / 2)), height / 48, "white")
    # 绘制边框。
    bs.border(width, height)
    t.done()


if __name__ == '__main__':
    main()
