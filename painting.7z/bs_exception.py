class BasicShapeException(Exception):
    pass


class AnglesMismatchingException(BasicShapeException):
    def __init__(self, sides, angles):
        self.sides = sides
        self.angles = angles

    def __str__(self):
        return "Angles' Number is Mismatching! "


