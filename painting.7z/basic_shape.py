import turtle as t
from math import *
from bs_exception import *


def move_to(x, y):
    t.penup()
    t.goto(x, y)
    t.pendown()
    t.setheading(0)


def line(left_domain, right_domain, color="black"):
    t.pencolor(color)
    t.pensize(2)

    move_to(left_domain, sin(left_domain))
    for i in range(right_domain - left_domain):
        t.goto(i + left_domain, sin(i + left_domain))


def rectangle(width, height, color="black"):
    t.color(color, color)
    t.pensize(0)

    t.begin_fill()
    for i in range(4):
        t.forward(width) if i % 2 == 0 else t.forward(height)
        t.right(90)
    t.end_fill()


def circle(radius, color="black"):
    t.color(color, color)
    t.pensize(0)

    # 移动画笔至参数指定位置，使得画出的圆之中心位于画笔的原初始位置。
    t.penup()
    t.right(90)
    t.forward(radius)
    t.left(90)
    t.pendown()

    t.begin_fill()
    t.circle(radius)
    t.end_fill()


def polygon(sides, angles, color="black"):
    t.color(color, color)
    t.pensize(0)

    t.begin_fill()
    try:
        if (len(sides) != len(angles)) & (len(sides) != len(angles) + 1):
            raise AnglesMismatchingException(sides, angles)
    except Exception as e:
        print("Can't paint the polygon: ")
        print(e)
    else:
        angles.append(0)
        for i in range(len(sides)):
            t.forward(sides[i])
            t.right(angles[i])
    t.end_fill()


def star(radius, color="black"):
    radius = float(radius)
    width = 2 * radius * sin(radians(72))
    arm = (width / 2) / (sin(radians(18)) + 1)
    move_up = radius - arm * cos(radians(18))
    move_left = width / 2

    t.color(color, color)
    t.pensize(0)

    # 移动画笔至参数指定位置，使得画出的星之中心位于画笔的原初始位置。
    t.penup()
    t.left(90)
    t.forward(move_up)
    t.left(90)
    t.forward(move_left)
    t.left(180)
    t.pendown()

    t.begin_fill()
    for i in range(5):
        t.forward(width)
        t.right(144)
    t.end_fill()


def border(x, y):
    t.pencolor("black")
    t.pensize(1)
    t.speed(50)

    move_to(-x / 2, y / 2)
    for i in range(4):
        t.forward(x) if i % 2 == 0 else t.forward(y)
        t.right(90)
